package com.example;

public class Premios {
    public double premioNivel1 = 1000;
    public double premioNivel2 = 2000;
    public double acumulado = 0;

}
