package com.example;

public class User {
    public String name;

    public User(String nombre) {
        this.name = nombre;
    }
}
